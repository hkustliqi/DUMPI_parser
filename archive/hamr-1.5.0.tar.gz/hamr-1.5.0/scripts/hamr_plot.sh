#!/bin/bash
#
# Plotting utility for hamr
# To plot the results of a hamr run, execute hamr with -q --no-sort
# and redirect the output to a text file.

if (( $# != 2 ))
then
    echo usage: plot.sh input_file_name output_file_name
    exit 1
fi

input=$1
output=$2
#title=$(head -n1 $input)
extension=$(echo $output | awk -F"." '{print $2}')

# create gnuplot script
echo set terminal $extension > plot.gnu
echo set output \'$output\' >> plot.gnu
echo set logscale x 2 >> plot.gnu
echo set title \'$title\' >> plot.gnu
echo set xlabel \'log_2\(message_size_in_bytes\)\' >> plot.gnu
echo set ylabel \'Bandwidth \(MB/s\)\' >> plot.gnu
echo plot \'$input\' using 1:3 with linespoints ti \'Min\' >> plot.gnu
echo set output \'$output\' >> plot.gnu
echo replot \'$input\' using 1:4 with linespoints ti \'Avg\' >> plot.gnu
echo set output \'$output\' >> plot.gnu
echo replot \'$input\' using 1:5 with linespoints ti \'Max\' >> plot.gnu

# plot
gnuplot plot.gnu

# remove the gnuplot script
# can always regenerate this by passing in the same input/output
rm -f plot.gnu
