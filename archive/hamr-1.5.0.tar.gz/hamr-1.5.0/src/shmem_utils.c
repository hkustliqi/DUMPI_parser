#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <mpp/shmem.h>

#include "shmem_utils.h"

#define  RANK       shmem_my_pe()
#define  NPES       shmem_n_pes()
#define  BARRIER()  shmem_barrier_all()

#define  MIN(A,B)   (((A)<(B))?(A):(B))
#define  MAX(A,B)   (((A)>(B))?(A):(B))


int shmem_check_shptrs( void *s, char *str ) {
  int                  i;
  static uint64_t shptrs;
  long            reduced;
  
  // Place pointer in variable depending on id
  shptrs = (long)s;

  // Global OR reduction to all, then verify local pointer matches
  // the reduced value.
  reduced = mpp_accum_or_long( shptrs );
  
  if( reduced != shptrs ) 
    return 0;
 
  return 1;
}

void * shmalloc_safe( size_t size, char *file, int line ) {
  void *buffer;
  buffer = shmalloc(size);
  if( !buffer ) {
    fprintf(stderr, "ERROR: shmalloc failed from allocation at %s:%d.\n", 
	    file, line);
    exit(1);
  }
  if( !shmem_check_shptrs( buffer, file ) ) {
    fprintf(stderr, "ERROR: Inconsistent shmem pointers "
	    "from allocation at %s:%d\n", file, line);
    exit(1);
  }
  return buffer;
}

/* void * shmalloc_aligned_safe( void *aligned, size_t size, int alignment, char *file, int line ) { */
/*   uintptr_t mask = ~(uintptr_t)(alignment - 1); */
/*   void * mem = shmalloc_safe ( size + alignment, file, line ); */
/*   aligned = (void *)(((uintptr_t)mem + alignment - 1) & mask); */
/*   printf("aligned Returning %lx\n", (long) mem); */
/*   return mem; */
/* } */

long  mpp_accum_long( long val ) {
  int i;
  static long dst, src;
  static long Sync[_SHMEM_REDUCE_SYNC_SIZE];
  static long Work[MAX(4, _SHMEM_REDUCE_MIN_WRKDATA_SIZE)];
  static int init=0;

  if (! init) {
    for (i = 0; i < _SHMEM_REDUCE_SYNC_SIZE; i++)
      Sync[i] = _SHMEM_SYNC_VALUE;
    init = 1;
  }

  src = val;
  BARRIER();
  shmem_long_sum_to_all (&dst, &src, 1, 0, 0, NPES, Work, Sync);

  return dst;
}

long  mpp_accum_or_long( long val ) {
  int i;
  static long dst, src;
  static long Sync[_SHMEM_REDUCE_SYNC_SIZE];
  static long Work[MAX(4, _SHMEM_REDUCE_MIN_WRKDATA_SIZE)];
  static int init=0;

  if (! init) {
    for (i = 0; i < _SHMEM_REDUCE_SYNC_SIZE; i++)
      Sync[i] = _SHMEM_SYNC_VALUE;
    init = 1;
  }
  
  src = val;
  BARRIER();
  shmem_long_or_to_all (&dst, &src, 1, 0, 0, NPES, Work, Sync);
  
  return dst;
}

void mpp_broadcast_long( long *val, int root ) {
  int i;
  static long dst, src;
  static long Sync[_SHMEM_BCAST_SYNC_SIZE];
  static int init=0;
  
  if (! init) {
    for (i = 0; i < _SHMEM_BCAST_SYNC_SIZE; i++)
      Sync[i] = _SHMEM_SYNC_VALUE;
    init = 1;
  }

  src = *val;
  BARRIER();
  shmem_broadcast64 (&dst, &src, 1, root, 0, 0, NPES, Sync);

  if( RANK != root )
    *val = dst;
}

double  mpp_accum_double( double val ) {
  int i;
  static double dst, src;
  static long Sync[_SHMEM_REDUCE_SYNC_SIZE];
  static double Work[MAX(4, _SHMEM_REDUCE_MIN_WRKDATA_SIZE)];
  static int init=0;

  if (! init) {
    for (i = 0; i < _SHMEM_REDUCE_SYNC_SIZE; i++)
      Sync[i] = _SHMEM_SYNC_VALUE;
    init = 1;
  }

  src = val;
  BARRIER();
  shmem_double_sum_to_all (&dst, &src, 1, 0, 0, NPES, Work, Sync);

  return dst;
}

double  mpp_max_double( double val ) {
  int i;
  static double dst, src;
  static long Sync[_SHMEM_REDUCE_SYNC_SIZE];
  static double Work[MAX(4, _SHMEM_REDUCE_MIN_WRKDATA_SIZE)];
  static int init=0;

  if (! init) {
    for (i = 0; i < _SHMEM_REDUCE_SYNC_SIZE; i++)
      Sync[i] = _SHMEM_SYNC_VALUE;
    init = 1;
  }

  src = val;
  BARRIER();
  shmem_double_max_to_all (&dst, &src, 1, 0, 0, NPES, Work, Sync);

  return dst;
}

double  mpp_min_double( double val ) {
  int i;
  static double dst, src;
  static long Sync[_SHMEM_REDUCE_SYNC_SIZE];
  static double Work[MAX(4, _SHMEM_REDUCE_MIN_WRKDATA_SIZE)];
  static int init=0;

  if (! init) {
    for (i = 0; i < _SHMEM_REDUCE_SYNC_SIZE; i++)
      Sync[i] = _SHMEM_SYNC_VALUE;
    init = 1;
  }

  src = val;
  BARRIER();
  shmem_double_min_to_all (&dst, &src, 1, 0, 0, NPES, Work, Sync);

  return dst;
}
